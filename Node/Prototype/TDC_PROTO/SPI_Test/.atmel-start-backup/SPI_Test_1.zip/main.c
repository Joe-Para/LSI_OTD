#include <atmel_start.h>

#define SPI_0_SS PIO_PB3_IDX

int main(void)
{
	struct io_descriptor *io; 
	uint32_t *datain = 0;
	uint16_t *dataout = 0x01;
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	ioport_set_pin_dir(PIO_PB3_IDX, IOPORT_DIR_OUTPUT);
	ioport_set_pin_level(PIO_PB3_IDX, IOPORT_PIN_LEVEL_HIGH);
	
	spi_m_sync_get_io_descriptor(&SPI_0, &io)
	spi_m_sync_enable(&SPI_0);
	/* Replace with your application code */
	while (1) {
		
		gpio_set_pin_level(SPI_0_SS, true);
		io_write(io, &dataout, 2);
		io_read(io, datain,2);
		gpio_set_pin_level(SPI_0_SS, true);
		
		delay_ms(1);
	}
}